import javax.swing.JOptionPane;

public class RegistroPacientes {

    private Paciente[] pacientes;
    private int contador;

    public RegistroPacientes(int capacidad) {
        pacientes = new Paciente[capacidad];
        contador = 0;
    }

    public void registrarPaciente() {

        if (contador >= pacientes.length) {
            JOptionPane.showMessageDialog(null, "No hay espacio para más pacientes.");
            return;
        }

        String nombre = JOptionPane.showInputDialog("Ingrese el nombre del paciente:");
        String documento = JOptionPane.showInputDialog("Ingrese el documento:");

        int edad = Integer.parseInt(JOptionPane.showInputDialog("Ingrese la edad:"));

        String telefono = JOptionPane.showInputDialog("Ingrese el teléfono:");
        String correo = JOptionPane.showInputDialog("Ingrese el correo:");

        pacientes[contador] = new Paciente(nombre, documento, edad, telefono, correo);
        contador++;

        JOptionPane.showMessageDialog(null, "Paciente registrado correctamente.");
    }

    public void mostrarPacientes() {

        if (contador == 0) {
            JOptionPane.showMessageDialog(null, "No hay pacientes registrados.");
            return;
        }

        StringBuilder lista = new StringBuilder("Pacientes registrados:\n\n");

        for (int i = 0; i < contador; i++) {
            lista.append((i + 1)).append(". ").append("\n")
                 .append(pacientes[i].toString())
                 .append("\n----------------------\n");
        }

        JOptionPane.showMessageDialog(null, lista.toString());
    }
}
