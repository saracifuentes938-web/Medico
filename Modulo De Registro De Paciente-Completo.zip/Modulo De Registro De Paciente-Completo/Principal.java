import javax.swing.JOptionPane;

public class Principal {
    public static void main(String[] args) {

        RegistroPacientes registro = new RegistroPacientes(30);

        int opcion = 0;

        while (opcion != 3) {

            opcion = Integer.parseInt(JOptionPane.showInputDialog(
                    "MENÚ PRINCIPAL\n" +
                    "1. Registrar paciente\n" +
                    "2. Mostrar pacientes\n" +
                    "3. Salir\n"
            ));

            switch (opcion) {
                case 1:
                    registro.registrarPaciente();
                    break;
                case 2:
                    registro.mostrarPacientes();
                    break;
                case 3:
                    JOptionPane.showMessageDialog(null, "Saliendo...");
                    break;
                default:
                    JOptionPane.showMessageDialog(null, "Opción inválida");
            }
        }
    }
}