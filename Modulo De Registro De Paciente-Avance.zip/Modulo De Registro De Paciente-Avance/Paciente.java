public class Paciente {
    private String nombre;
    private String documento;
    private int edad;
    private String telefono;
    private String correo;

    public Paciente(String nombre, String documento, int edad, String telefono, String correo) {
        this.nombre = nombre;
        this.documento = documento;
        this.edad = edad;
        this.telefono = telefono;
        this.correo = correo;
    }

    public String getNombre() { return nombre; }
    public String getDocumento() { return documento; }
    public int getEdad() { return edad; }
    public String getTelefono() { return telefono; }
    public String getCorreo() { return correo; }

    @Override
    public String toString() {
        return "Paciente{" +
                "nombre='" + nombre + '\'' +
                ", documento='" + documento + '\'' +
                ", edad=" + edad +
                ", telefono='" + telefono + '\'' +
                ", correo='" + correo + '\'' +
                '}';
    }
}